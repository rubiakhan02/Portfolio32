import { useState } from "react";
import css from "../../public/css.jpg";

export default function Experiance() {
  const [expanded, setExpanded] = useState(false);

  const exp = {
    id: 1,
    logo: css,
    title: "AI Moderation & Automation Intern",
    company: "Vyorius Drones Private Limited",
    duration: "May – June 2025",
    bullets: [
      "Developed real-time automation pipelines integrating REST APIs and logic-based workflows to optimize drone task management and decision-making.",
      "Built intelligent agent-like systems using AI models for contextual understanding, goal-driven behavior, and operational efficiency.",
      "Collaborated cross-functionally to align backend services with system-level automation, enhancing reliability and modularity.",
      "Contributed to QGroundControl-based infrastructure, refining UI logic and integrating telemetry insights into automation flows.",
      "Authored technical documentation on system design, experiment results, and AI agent performance; continuously monitored trends in applied AI and autonomous systems."
    ]
  };

  return (
    <div
      name="Experiance"
      className="max-w-screen-2xl mx-auto px-4 md:px-20 my-16"
    >
      <h1 className="text-3xl font-bold mb-5">Experience</h1>
      <div className="flex justify-center">
        <div className="w-full md:w-3/4">
          <div
            key={exp.id}
            className="
              flex flex-col justify-between
              bg-pink-50 border border-pink-200 rounded-lg shadow-lg
              p-6
              transition-transform hover:scale-105
            "
          >
            <div className="flex flex-col items-center">
              <img
                src={exp.logo}
                alt={exp.title}
                className="w-24 h-24 rounded-full border-2 border-pink-200 mb-4"
              />
              <h2 className="text-xl font-bold mb-1">{exp.title}</h2>
              <p className="text-sm text-gray-600">{exp.company}</p>
              <p className="text-sm text-gray-600">{exp.duration}</p>
            </div>

            <div className="flex-1 mb-4 relative">
              <ul
                className={`text-gray-700 text-sm leading-relaxed transition-[max-height] overflow-hidden ${
                  expanded ? "max-h-[500px]" : "max-h-24"
                }`}
              >
                {exp.bullets.map((b, i) => (
                  <li key={i} className="mb-2">
                    {b}
                  </li>
                ))}
              </ul>
              <button
                onClick={() => setExpanded((prev) => !prev)}
                className="text-blue-500 text-sm mt-1 underline"
              >
                {expanded ? "Show less" : "Show more"}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
