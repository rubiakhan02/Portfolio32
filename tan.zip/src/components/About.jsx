
export default function About() {
  return (
    <div
      name="About"
      className="max-w-screen-2xl container mx-auto px-4 md:px-20 my-20"
    >
      {/* Intro */}
      <h1 className="text-3xl font-bold mb-1">About</h1>
      <p className="text-lg mb-6">
        Final Year Undergraduate — Computer Science Engineering (Data Science) at Pranveer Singh Institute of Technology, Kanpur.
      </p>
      <p className="mb-8">
        Hello, I’m Tanya Pal. I’m passionate about machine learning, AI-driven solutions, and full-stack development. With hands-on experience in real-time automation pipelines, AI agent systems, and competitive programming, I love solving complex problems and building innovative software that makes an impact.
      </p>

      {/* Education & Training */}
      <h2 className="text-green-600 font-semibold text-xl mb-4">
        Education &amp; Training
      </h2>
      <div className="space-y-6 mb-10">
        <div className="bg-gray-50 p-6 rounded-lg shadow-sm">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
            <div>
              <h3 className="font-semibold">
                Pranveer Singh Institute of Technology, Kanpur, UP
              </h3>
              <p>Computer Science Engineering (Data Science) — Final Year Undergraduate</p>
            </div>
            <div className="text-gray-600 text-sm mt-2 md:mt-0 text-right">
              <p>December 2022 – July 2026</p>
              <p>CGPA: 7.0</p>
            </div>
          </div>
        </div>
        <div className="bg-gray-50 p-6 rounded-lg shadow-sm">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
            <div>
              <h3 className="font-semibold">
                The Jain International School, Kanpur, UP
              </h3>
              <p>CBSE — PCM</p>
            </div>
            <div className="text-gray-600 text-sm mt-2 md:mt-0 text-right">
              <p>2021 – 2022</p>
            </div>
          </div>
        </div>
      </div>

      {/* Skills */}
      <h2 className="text-green-600 font-semibold text-xl mb-4">Skills</h2>
      <div className="bg-gray-50 p-6 rounded-lg shadow-sm">
        <p>
          <span className="font-semibold">Programming Languages:</span> Python, C, C++
        </p>
        <p>
          <span className="font-semibold">Data Science:</span> Machine Learning, Deep Learning, NLP, Generative AI, OpenCV
        </p>
        <p>
          <span className="font-semibold">Web Technologies:</span> HTML, CSS, JavaScript, React.js
        </p>
        <p>
          <span className="font-semibold">Tools &amp; Frameworks:</span> Git, REST APIs, PyTorch, TensorFlow, Scikit-learn, Azure, AWS, CI/CD
        </p>
        <p>
          <span className="font-semibold">Database:</span> MySQL
        </p>
      </div>
    </div>
  );
}
