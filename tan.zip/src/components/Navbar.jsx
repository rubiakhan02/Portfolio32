import { useState } from "react";
import { AiOutlineMenu } from "react-icons/ai";
import { IoCloseSharp } from "react-icons/io5";
import { Link } from "react-scroll";
import pic from "../../public/photo.avif";

function Navbar() {
  const [menu, setMenu] = useState(false);

  // note separate `label` (what you see) vs. `to` (anchor name)
  const navItems = [
    { id: 1, label: "Home",      to: "Home"       },
    { id: 2, label: "About",     to: "About"      },
    { id: 3, label: "Projects",  to: "Projects"   },
    { id: 4, label: "Tech",      to: "Experiance" }, // scrolls to name="Experiance"
    { id: 5, label: "Contact",   to: "Contact"    },
  ];

  return (
    <div className="fixed top-0 left-0 right-0 z-50 h-16 shadow-md bg-gray-100">
      <div className="max-w-screen-2xl container mx-auto px-4 md:px-20 flex justify-between items-center h-full">
        {/* logo */}
        <div className="flex space-x-2">
          <img src={pic} className="h-12 w-12 rounded-full" alt="profile" />
          <div>
            <h1 className="font-semibold text-xl cursor-pointer">
              Taniya<span className="text-green-500 text-2xl">l</span>
            </h1>
            <p className="text-sm">Web Developer</p>
          </div>
        </div>

        {/* desktop menu */}
        <ul className="hidden md:flex space-x-8">
          {navItems.map(({ id, label, to }) => (
            <li key={id} className="hover:scale-105 duration-200 cursor-pointer">
              <Link
                to={to}
                smooth={true}
                duration={500}
                offset={-70}
                activeClass="active"
              >
                {label}
              </Link>
            </li>
          ))}
        </ul>

        {/* mobile toggle */}
        <div className="md:hidden" onClick={() => setMenu(!menu)}>
          {menu ? <IoCloseSharp size={24} /> : <AiOutlineMenu size={24} />}
        </div>
      </div>

      {/* mobile menu */}
      {menu && (
        <div className="bg-gray-100 md:hidden">
          <ul className="flex flex-col h-screen items-center justify-center space-y-3 text-xl">
            {navItems.map(({ id, label, to }) => (
              <li key={id} className="hover:scale-105 duration-200 font-semibold cursor-pointer">
                <Link
                  to={to}
                  smooth={true}
                  duration={500}
                  offset={-70}
                  onClick={() => setMenu(false)}
                  activeClass="active"
                >
                  {label}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

export default Navbar;
