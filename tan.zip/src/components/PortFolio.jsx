import { useState } from "react";
import { FaGithub } from "react-icons/fa";
import nodejs from "../../public/node.png";
import reactjs from "../../public/reactjs.png";
import spring from "../../public/spring.png";

export default function PortFolio() {
  const [expanded, setExpanded] = useState({});

  const cardItem = [
    {
      id: 1,
      logo: reactjs,
      name: "MediScanAI",
      description:
        "Developed a robust AI model leveraging Convolutional Neural Networks (CNNs) on 180×180 X-ray images to detect abnormalities with 95% accuracy, 0.93 precision, and 0.92 F1-score. Engineered a medicine recognition system that classifies drug images and retrieves critical information including usage guidelines, dosage instructions, and potential side effects. Integrated REST APIs and managed state efficiently using React hooks through a responsive UI supporting real-time file uploads, personalized health insights, and smooth navigation.",
      link: "https://github.com/tanya-pal/MedScanAI",
    },
    {
      id: 2,
      logo: spring,
      name: "Brainy Ally",
      description:
        "Built an empathetic mental health chatbot offering active listening, coping strategies, and motivational support to enhance emotional well-being. Designed a responsive and intuitive user interface ensuring smooth user experience across devices and platforms. Enabled 24/7 availability, providing users with consistent, accessible mental health support through a reliable digital companion.",
      link: "https://github.com/tanya-pal/Brainly-ally",
    },
    {
      id: 3,
      logo: nodejs,
      name: "Grammar Scoring Engine",
      description:
        "Developed a speech-based AI system to score spoken grammar (0–5) using MFCC features and supervised regression modeling. Achieved a Pearson Correlation of 0.82 with an optimized Random Forest Regressor, closely matching human-rated grammar scores. Enhanced audio input quality through silence trimming, noise reduction, and normalization, improving model robustness and accuracy.",
      link: "https://github.com/tanya-pal/Grammar-Scoring-Engine-",
    },
  ];

  return (
    <div
      name="Projects"
      className="max-w-screen-2xl mx-auto px-4 md:px-20 mt-10"
    >
      <h1 className="text-3xl font-bold mb-5">Projects</h1>
      <span className="underline font-semibold">Featured Projects</span>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-stretch mt-6">
        {cardItem.map(({ id, logo, name, description, link }) => (
          <div
            key={id}
            className="
              flex flex-col justify-between
              bg-pink-50 border border-pink-200 rounded-lg shadow-lg
              p-6 h-full
              transition-transform hover:scale-105
            "
          >
            <div className="flex flex-col items-center">
              <img
                src={logo}
                alt={name}
                className="w-24 h-24 rounded-full border-2 border-pink-200 mb-4"
              />
              <h2 className="text-xl font-bold mb-2">{name}</h2>
            </div>

            <div className="flex-1 mb-4 relative">
              <p
                className={`text-gray-700 text-sm leading-relaxed transition-[max-height] overflow-hidden ${
                  expanded[id] ? "max-h-[200px]" : "max-h-20"
                }`}
              >
                {description}
              </p>
              <button
                onClick={() =>
                  setExpanded((prev) => ({ ...prev, [id]: !prev[id] }))
                }
                className="text-blue-500 text-sm mt-1 underline"
              >
                {expanded[id] ? "Read less" : "Read more"}
              </button>
            </div>

            <a href={link} target="_blank" rel="noopener noreferrer">
              <button className="mt-4 w-full inline-flex items-center justify-center bg-gradient-to-r from-pink-500 to-red-500 hover:from-pink-600 hover:to-red-600 text-white font-semibold px-6 py-2 rounded-full shadow-lg transform transition-transform duration-300 hover:scale-105">
                <FaGithub className="mr-2 text-lg" />
                Source Code
              </button>
            </a>
          </div>
        ))}
      </div>
    </div>
  );
}
